document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('feedbackForm');
  const responseDiv = document.getElementById('response');

  form.addEventListener('submit', (event) => {
    event.preventDefault();

    const name = form.name.value.trim();
    const email = form.email.value.trim();

    if (!name || !email) {
      alert("Please fill out all required fields!");
      return;
    }

    responseDiv.innerHTML = `<p>Thanks, ${name}! Your feedback has been received.</p>`;
    form.reset();
  });
});
